This directory includes a few sample datasets to get you started.

nobel_prize_by_winner*.csv is Nobel Prize data from the 1901 to 2022; more information is available at: 
https://www.kaggle.com/datasets/rishidamarla/nobel-prize-winners-19002020

For second expreminet, a Wikipedia page is used, which is described at: https://en.wikipedia.org/wiki/List_of_Nobel_laureates_by_country

For third experiment, a web page is used, which is described at:
https://stats.areppim.com/listes/list_nobelxprize.htm

Experiment 1:
A Kaggle dataset is used and required libreries were were like pandas, nltk, matplotlib and numpy. 
I extarted the data from kaggle data set in 3 sections. 
	. First, I found the top 2 countries holding the nobel prizes
	. Then, plotted a histogram of their age when receiving the prize.
	. Finally gives a list of most common words words used in the title.
	
Experiment 2:
A Wikipedia page is used for experiment 2 where in all the required librerieswere imported like BeautifulSoup, request, and collections.
In this experiment, most common words were extarcted and confimred the results from experiment 1.

Experiment 3:
A website is used for experiment 3 where in I extrated the data to compare the male and female count and plotted a grapgh in the field of chemistry. 